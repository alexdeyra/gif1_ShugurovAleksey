﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gifzachet1
{
    public partial class Form1 : Form
    {
        private List<Country> countries;
        private List<Hotel> hotels;

        public Form1()
        {
            InitializeComponent();
            InitializeData();
        }
        private void InitializeData()
        {
            countries = new List<Country>
            {
                new Country { Id = 1, Name = "Турция" },
                new Country { Id = 2, Name = "Египет" },
                new Country { Id = 3, Name = "Италия" }
            };

            hotels = new List<Hotel>
            {
                new Hotel { Type = "2*", Id = 1, Name = "Rivas", Price = 2000 },
                new Hotel { Type = "1*", Id = 2, Name = "Sonesta", Price = 1600 },
                new Hotel { Type = "3*", Id = 3, Name = "Excelsior", Price = 2500 }
            };
        }


        private void btnJoin_Click_1(object sender, EventArgs e)
        {
            string sortParam = (string)cbSortParam.SelectedItem;
            IEnumerable<JoinedData> joinedData = JoinData(sortParam);

            dataGridView1.DataSource = joinedData.ToList();
        }
        private IEnumerable<JoinedData> JoinData(string sortParam)
        {
            var joined = from c in countries
                         join h in hotels on c.Id equals h.Id
                         orderby GetSortValue(h, sortParam)
                         select new JoinedData
                         {
                             TripId = h.Id,
                             HotelName = h.Name,
                             Country = c.Name,
                             Quantity = 1,
                             Price = h.Price
                         };

            return joined;
        }

        private double GetSortValue(Hotel hotel, string sortParam)
        {
            switch (sortParam)
            {
                case "Цена":
                    return hotel.Price;
                case "Название отеля":
                    return hotel.Name.Length;
                default:
                    return hotel.Id;
            }
        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int tripId = (int)dataGridView1.SelectedRows[0].Cells["TripId"].Value;
                DeleteRecord(tripId);
                dataGridView1.DataSource = JoinData((string)cbSortParam.SelectedItem).ToList();
            }
        }
        private void DeleteRecord(int tripId)
        {
            var joined = JoinData((string)cbSortParam.SelectedItem).ToList();
            var recordToDelete = joined.FirstOrDefault(r => r.TripId == tripId);
            if (recordToDelete != null)
            {
                joined.Remove(recordToDelete);
            }
        }
    }

    public class Country
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class Hotel
    {
        public string Type { get; set; }
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
    }

    public class JoinedData
    {
        public int TripId { get; set; }
        public string HotelName { get; set; }
        public string Country { get; set; }
        public int Quantity { get; set; }
        public double Price { get; set; }
    }
}